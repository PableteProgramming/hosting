#pragma once
#include <vector>
#include <string>
#ifdef MENU_EXPORTS
#define MENU_API __declspec(dllexport)
#else
#define MENU_API __declspec(dllimport)
#endif

extern "C" class MENU_API Menu {
private:
	std::vector<std::string> items;
	int index;
	int numelem;
	bool running;
	int GetConsoleWidth();
	int GetConsoleHeight();
	void ColorSelectedIndex(int ii, int x, int y);
	void HideCursor();
	void Move();
	void gotoxy(int x, int y);
	void ChangeForeAndBackGroundColor(int ForC, int BackC);
public:
	Menu(std::vector<std::string> it);
	int Show(int i, int x, int y);
};